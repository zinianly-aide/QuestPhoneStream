# Meta Quest Developer Hub Skill

Use MQDH for:
- Device management
- Casting headset view to Mac
- Recording
- Screenshots
- ADB over Wi-Fi
- Performance tools
- Log viewing

MQDH is the easiest way for the user to see Quest output on Mac.
