# Troubleshooting Skill

When there is an error:
1. Copy exact error
2. Search official docs first
3. Compare at least 3 useful sources when possible
4. Summarize cause
5. Apply minimal fix
6. Validate again
7. Record lesson in docs/lessons-learned.md
