# Quest Expert Agent Pack v2

Drop this folder's contents into the root of your Quest 3 / Quest 3S Unity project.

It helps code agents such as OpenClaw, Claude Code, Codex, Cursor, and similar tools understand:

- Quest 3 / Quest 3S development
- Unity + Meta XR SDK
- ADB debugging
- MQDH workflow
- WebRTC / phone streaming
- Build-install-logcat validation
- Research-first development workflow

## Quick Start

```bash
chmod +x scripts/*.sh
./scripts/check-quest-env.sh
./scripts/quest-adb-debug.sh
```

## Main Files

- `AGENTS.md` — global agent instructions
- `.claw/skills/*` — OpenClaw skills
- `.claude/commands/*` — Claude Code commands
- `.codex/quest-agent.md` — Codex agent profile
- `.cursor/rules/*` — Cursor project rules
- `scripts/*` — Quest build/debug helper scripts
- `unity/Editor/QuestBuildScript.cs` — Unity batch build entry
- `docs/*` — knowledge base and research templates
