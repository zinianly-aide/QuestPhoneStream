#!/usr/bin/env bash
set -e

UNITY_PATH="${UNITY_PATH:-/Applications/Unity/Hub/Editor/6000.0.0f1/Unity.app/Contents/MacOS/Unity}"
PROJECT_PATH="${PROJECT_PATH:-$(pwd)}"

"$UNITY_PATH"   -batchmode   -quit   -projectPath "$PROJECT_PATH"   -executeMethod QuestBuildScript.BuildAndroid   -logFile build/unity-build.log

echo "Build log: build/unity-build.log"
