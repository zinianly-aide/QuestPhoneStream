# WebRTC / Streaming Skill

For phone-to-Quest streaming, research before implementation:
- Unity WebRTC
- WebRTC signaling
- STUN/TURN
- H.264 / VP8 support
- Android MediaCodec
- Low-latency texture rendering
- Audio sync
- Network jitter
- Reconnect logic

Never assume simulator results equal real Quest streaming behavior.
