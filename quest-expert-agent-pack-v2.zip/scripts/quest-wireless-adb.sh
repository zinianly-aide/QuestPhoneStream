#!/usr/bin/env bash
set -e

echo "Connect Quest by USB first."
adb devices

echo "Enable TCP/IP ADB..."
adb tcpip 5555

echo "Quest wlan0 IP:"
adb shell ip addr show wlan0 | grep 'inet ' || true

echo ""
echo "Then run:"
echo "adb connect QUEST_IP:5555"
