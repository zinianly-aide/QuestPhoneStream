# Android Build Skill

Check:
- AndroidManifest.xml
- Gradle errors
- SDK / NDK / JDK
- Permissions
- ABI
- IL2CPP
- Min/Target SDK
- Runtime crashes via AndroidRuntime logcat
