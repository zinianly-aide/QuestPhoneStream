# Unity MCP Notes

If using a Unity MCP server, expose capabilities for:
- Reading scenes
- Reading project settings
- Running editor scripts
- Triggering Android build
- Reporting console errors
- Inspecting prefabs

The agent should still validate Quest-specific behavior on real hardware.
