# /quest-debug

Run Quest debug workflow:

1. Check `adb devices`
2. If unauthorized, ask user to accept USB debugging in headset
3. Build APK if build script exists
4. Install APK
5. Launch package
6. Capture `adb logcat -s Unity AndroidRuntime`
7. Summarize errors and fix candidates
