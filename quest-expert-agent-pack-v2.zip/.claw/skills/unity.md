# Unity XR Skill

Check:
- Unity version
- Packages/manifest.json
- ProjectSettings/XR settings
- Android Player Settings
- Gradle settings
- Scripting backend
- Minimum API level
- Target API level

Prefer:
- Unity 6 LTS or Unity 2022 LTS
- OpenXR
- Meta XR SDK
