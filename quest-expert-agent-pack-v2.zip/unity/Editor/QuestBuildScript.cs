#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build.Reporting;
using System.IO;

public static class QuestBuildScript
{
    public static void BuildAndroid()
    {
        Directory.CreateDirectory("build");

        string[] scenes = GetEnabledScenes();
        string output = "build/QuestApp.apk";

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

        BuildPlayerOptions options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = output,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);

        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new System.Exception("Android build failed: " + report.summary.result);
        }

        UnityEngine.Debug.Log("Android build succeeded: " + output);
    }

    private static string[] GetEnabledScenes()
    {
        var scenes = EditorBuildSettings.scenes;
        var enabled = new System.Collections.Generic.List<string>();

        foreach (var scene in scenes)
        {
            if (scene.enabled)
            {
                enabled.Add(scene.path);
            }
        }

        if (enabled.Count == 0)
        {
            throw new System.Exception("No enabled scenes in Build Settings.");
        }

        return enabled.ToArray();
    }
}
#endif
