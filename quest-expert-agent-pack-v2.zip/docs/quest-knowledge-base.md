# Quest Knowledge Base

## Development Stack
- Unity
- OpenXR
- Meta XR SDK
- Android
- ADB
- MQDH

## Simulator vs Real Device
Use Meta XR Simulator for quick editor checks.
Use real Quest for performance, permissions, passthrough, hand tracking, controllers, and streaming.

## Debug Loop
Build → Install → Launch → Logcat → Fix.
