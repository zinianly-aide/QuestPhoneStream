#!/usr/bin/env bash
set -e

PKG_NAME="${PKG_NAME:-com.yourcompany.questapp}"
APK_PATH="${APK_PATH:-build/QuestApp.apk}"

echo "== ADB devices =="
adb devices

echo ""
echo "If device shows unauthorized, wear headset and allow USB debugging."

if [ -f "$APK_PATH" ]; then
  echo "== Install APK: $APK_PATH =="
  adb install -r "$APK_PATH"
else
  echo "APK not found: $APK_PATH"
  echo "Set APK_PATH=/path/to/app.apk"
fi

echo "== Clear logs =="
adb logcat -c || true

echo "== Launch app: $PKG_NAME =="
adb shell monkey -p "$PKG_NAME" 1 || true

echo "== Logs: Unity + AndroidRuntime =="
adb logcat -s Unity AndroidRuntime
