#!/usr/bin/env bash
set -e

OUT="${1:-quest-recording.mp4}"

echo "Recording 20 seconds from headset..."
adb shell screenrecord --time-limit 20 /sdcard/quest-recording.mp4
adb pull /sdcard/quest-recording.mp4 "$OUT"
echo "Saved: $OUT"
