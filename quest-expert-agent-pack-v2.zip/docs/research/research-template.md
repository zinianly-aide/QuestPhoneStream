# Research Note

## Question

## Sources Checked

1.
2.
3.

## Findings

## Decision

## Implementation Plan

## Validation Plan
