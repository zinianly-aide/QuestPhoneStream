# Quest 3 / Quest 3S Skill

The agent must understand:
- Meta Quest Android deployment
- OpenXR runtime
- Meta XR SDK
- Controller input
- Hand tracking
- Passthrough
- Boundary / guardian behavior
- Performance constraints

Validation must use real device for:
- Performance
- Controller behavior
- Hand tracking
- Passthrough
- Video streaming
- Android permissions
