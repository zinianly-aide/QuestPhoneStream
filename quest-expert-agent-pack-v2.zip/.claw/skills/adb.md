# ADB Skill

Common commands:

```bash
adb devices
adb kill-server
adb start-server
adb install -r path/to/app.apk
adb uninstall com.example.app
adb shell monkey -p com.example.app 1
adb logcat -s Unity AndroidRuntime
adb tcpip 5555
adb connect QUEST_IP:5555
adb shell screenrecord /sdcard/quest-demo.mp4
adb pull /sdcard/quest-demo.mp4 .
```

If device is unauthorized:
- Tell user to wear headset
- Accept USB debugging
- Check Always allow from this computer
