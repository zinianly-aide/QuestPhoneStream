# WebRTC Streaming Notes

## Target
Android phone → signaling → Quest Unity app.

## Key Topics
- Signaling server
- STUN / TURN
- Codec compatibility
- Unity texture rendering
- Latency
- Reconnect
- Resolution adaptation
- Audio sync

## Risks
- Simulator cannot fully validate Quest video performance
- Network conditions strongly affect latency
- Android capture pipeline may require device-specific fixes
