# /quest-scan

Scan this Unity Quest project.

Steps:
1. Read README.md and AGENTS.md
2. Inspect Packages/manifest.json
3. Inspect ProjectSettings
4. Inspect Assets folder structure
5. Identify Unity version and XR stack
6. Write docs/project-analysis.md

Output:
- Current architecture
- SDKs used
- Missing setup
- Risks
- Next recommended actions
