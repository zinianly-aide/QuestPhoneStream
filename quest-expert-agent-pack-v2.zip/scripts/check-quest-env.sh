#!/usr/bin/env bash
set -e

echo "== macOS =="
sw_vers || true

echo ""
echo "== Java =="
java -version || true

echo ""
echo "== ADB =="
which adb || true
adb version || true

echo ""
echo "== Android SDK =="
echo "ANDROID_HOME=$ANDROID_HOME"
echo "ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"
ls "$HOME/Library/Android/sdk" 2>/dev/null || true

echo ""
echo "== Unity Editors =="
ls /Applications/Unity/Hub/Editor 2>/dev/null || true

echo ""
echo "== Quest Devices =="
adb devices || true
